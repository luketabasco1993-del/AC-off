package com.example.acoff

import android.app.Activity
import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * AC "power off" scanner.
 *
 * Reads assets/codes.txt and fires each code in turn (every GAP_MS) so you can
 * watch/listen for the AC to react. Tap "It turned off!" when it does.
 *
 * codes.txt line formats (blank lines and # comments ignored):
 *   raw: label|raw|38000|9000,4500,560,560,...      (mark/space durations in microseconds)
 *   nec: label|nec|ADDR_HEX|CMD_HEX                 e.g.  Brand X|nec|00|1F   (or 4-hex-digit addr)
 *
 * Raw lines match Flipper-IRDB .ir "raw" signals (frequency + data), so you can
 * paste codes from there for brands you want to try.
 */
class MainActivity : Activity() {

    private data class Code(val label: String, val freq: Int, val pattern: IntArray)

    private lateinit var ir: ConsumerIrManager
    private val handler = Handler(Looper.getMainLooper())
    private var codes: List<Code> = emptyList()
    private var index = 0
    private var running = false

    private lateinit var status: TextView
    private lateinit var startBtn: Button

    private val GAP_MS = 3000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ir = getSystemService(Context.CONSUMER_IR_SERVICE) as ConsumerIrManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        status = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER }
        startBtn = Button(this).apply { text = "Start scan" }
        val workedBtn = Button(this).apply { text = "It turned off!" }
        val resendBtn = Button(this).apply { text = "Resend last code" }
        val resetBtn = Button(this).apply { text = "Restart from beginning" }

        root.addView(status)
        root.addView(startBtn)
        root.addView(workedBtn)
        root.addView(resendBtn)
        root.addView(resetBtn)
        setContentView(root)

        if (!ir.hasIrEmitter()) {
            status.text = "This phone has no IR emitter."
            startBtn.isEnabled = false
            workedBtn.isEnabled = false
            resendBtn.isEnabled = false
            resetBtn.isEnabled = false
            return
        }

        codes = loadCodes()
        status.text = "${codes.size} codes loaded.\nPoint the phone's IR window at the AC."

        startBtn.setOnClickListener {
            if (running) pause() else start()
        }
        workedBtn.setOnClickListener {
            pause()
            val last = codes.getOrNull(index - 1)
            status.text = if (last != null)
                "Match: ${last.label}\n(Resend to confirm, or restart.)"
            else "Nothing sent yet."
        }
        resendBtn.setOnClickListener { codes.getOrNull(index - 1)?.let { send(it) } }
        resetBtn.setOnClickListener { pause(); index = 0; status.text = "Reset." }
    }

    private fun start() {
        if (codes.isEmpty()) { status.text = "No codes found in assets/codes.txt"; return }
        running = true
        startBtn.text = "Pause"
        step()
    }

    private fun pause() {
        running = false
        handler.removeCallbacksAndMessages(null)
        startBtn.text = "Start scan"
    }

    private fun step() {
        if (!running) return
        if (index >= codes.size) {
            status.text = "Reached the end of the list."
            pause()
            return
        }
        val code = codes[index++]
        status.text = "Sending ${index}/${codes.size}\n${code.label}"
        send(code)
        handler.postDelayed({ step() }, GAP_MS)
    }

    private fun send(code: Code) {
        try {
            ir.transmit(code.freq, code.pattern)
        } catch (e: Exception) {
            status.text = "Transmit failed: ${e.message}"
        }
    }

    private fun loadCodes(): List<Code> {
        val out = mutableListOf<Code>()
        try {
            assets.open("codes.txt").bufferedReader().useLines { lines ->
                for (raw in lines) {
                    val line = raw.trim()
                    if (line.isEmpty() || line.startsWith("#")) continue
                    val p = line.split("|").map { it.trim() }
                    try {
                        when (p.getOrNull(1)?.lowercase()) {
                            "raw" -> out += Code(
                                p[0], p[2].toInt(),
                                p[3].split(",").map { it.trim().toInt() }.toIntArray()
                            )
                            "nec" -> out += Code(p[0], 38000, necPattern(p[2], p[3]))
                        }
                    } catch (_: Exception) { /* skip malformed line */ }
                }
            }
        } catch (_: Exception) { }
        return out
    }

    /** Standard NEC: 9ms/4.5ms header, LSB first, 560us marks, 1690us/560us spaces. */
    private fun necPattern(addrHex: String, cmdHex: String): IntArray {
        val addr = addrHex.toInt(16)
        val cmd = cmdHex.toInt(16) and 0xFF
        val bits = ArrayList<Int>()
        if (addrHex.length > 2) {
            for (i in 0 until 16) bits += (addr shr i) and 1          // extended 16-bit address
        } else {
            for (i in 0 until 8) bits += (addr shr i) and 1
            for (i in 0 until 8) bits += ((addr.inv() and 0xFF) shr i) and 1
        }
        for (i in 0 until 8) bits += (cmd shr i) and 1
        for (i in 0 until 8) bits += ((cmd.inv() and 0xFF) shr i) and 1

        val p = ArrayList<Int>()
        p += 9000; p += 4500
        for (b in bits) { p += 560; p += if (b == 1) 1690 else 560 }
        p += 560                                                      // stop mark
        return p.toIntArray()
    }
}
